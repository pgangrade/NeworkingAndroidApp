package mad.uncc.batterylevel;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.TimeUnit;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    StringBuilder fileContent = new StringBuilder();
    final String filename = "myfile.txt";
    IntentFilter ifilter;
    Intent batteryStatus;
    File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
         batteryStatus = MainActivity.this.registerReceiver(null, ifilter);


        file = new File(MainActivity.this.getExternalFilesDir(Environment.DIRECTORY_PICTURES), filename);

        findViewById(R.id.click).setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if(isConnected()){
                    fileContent.setLength(0);
                    fileContent.append(checkBattery() + "\n");
                    fileContent.append("Connected to Internet\n");
                    fileContent.append(getConnectedType()+"\n");}
                else{
                    fileContent.setLength(0);
                    fileContent.append("Not Connected\n");
                }
                try {
                    FileOutputStream outputStream;
                    outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(fileContent.toString().getBytes());
                    outputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        findViewById(R.id.load).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FileInputStream inputStream;
                try {
                    inputStream = openFileInput(filename);
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader br = new BufferedReader(inputStreamReader);
                    StringBuilder sb = new StringBuilder();
                    sb.setLength(0);
                    String line="";
                    while((line = br.readLine()) !=null){
                        sb.append(line);
                    }
                    Toast.makeText(MainActivity.this,sb,Toast.LENGTH_SHORT).show();
                    file.delete();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo ==null || !networkInfo.isConnected() || (networkInfo.getType() !=ConnectivityManager.TYPE_WIFI
                && networkInfo.getType() !=  connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    public String getConnectedType(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        String type= null;
        if(networkInfo.getType() ==ConnectivityManager.TYPE_WIFI){
            type = "WIFI";
        }else if(networkInfo.getType() ==  connectivityManager.TYPE_MOBILE){
            type = "MOBILE";
        }
        else
            type = "Not Connected";
     return type;
    }

    public String checkBattery(){
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        String temp="";
        temp = "Current Battery level : " + level +"%\n";
        return temp;
    }
}
